<div class="section">
  <h2 class="hgroup cf"><?php _l('error.headline') ?></h2>
  <p><?php echo html($text) ?></p>
</div>