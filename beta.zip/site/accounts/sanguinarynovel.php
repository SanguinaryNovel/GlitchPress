<?php if(!defined('KIRBY')) exit ?>

username: sanguinarynovel
password: >
  $2a$10$Tf6VX33PUhVYuh/mrWHdtuXVCHzzpxYZT.9b/E0ve5VfQazkcNlrm
email: aberrant.whimsy@gmail.com
language: en
role: admin
history:
  - >
    projects/msbo-baseball-hospitality-invite
  - projects/artificial-turf-diagram
  - projects/mattawan-later-elementary-mural
  - projects/kingscott-holiday-package
  - projects/kbac-brochure
