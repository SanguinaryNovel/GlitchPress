	<footer class="footer cf" role="contentinfo">
		<div class="colophon">
			<a href="http://getkirby.com/made-with-kirby-and-love">Made in Kirby with <span class="heart"></span></a>
		</div>
	</footer>

</div>

<?php echo js('https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js') ?>
<?php echo js('assets/js/scripts.js') ?>
</body>
</html>