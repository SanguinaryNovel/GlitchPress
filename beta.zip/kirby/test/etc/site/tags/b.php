<?php

kirbytext::$tags['b'] = array();